﻿
using System.Reflection;

[assembly: AssemblyTitle("CloseAll")]
[assembly: AssemblyVersion("1.7.*")]
[assembly: AssemblyProduct("CloseAll")]